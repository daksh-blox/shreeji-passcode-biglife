<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
    <link rel="apple-touch-icon" sizes="180x180" href="favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicons/favicon-16x16.png">
    <link rel="manifest" href="favicons/site.html">
    <link rel="mask-icon" href="favicons/safari-pinned-tab.svg" color="#5bbad5">
    <link rel="shortcut icon" href="favicons/favicon.ico">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="msapplication-config" content="favicons/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
    <title>Passcode Big Life by Shree Supernest - 2 & 3 BHK Super Apartments | Shreeji Group</title>
    <meta name="description" content="Passcode Big Life by Shree Supernest - 2 & 3 BHK Super Apartments" />
    <link rel="stylesheet" href="css/styles.css" type="text/css" defer />
    <link rel="stylesheet" href="css/fontawesome/css/font-awesome.min.css" type="text/css" defer />
    <link rel="stylesheet" href="css/animate.css" type="text/css" async />
    <link rel="stylesheet" href="css/slick.css" type="text/css" async />
    <link rel="stylesheet" href="css/fancybox/jquery.fancybox.css" type="text/css" async />

    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@600&amp;family=Montserrat:wght@200;300;400;600;800&amp;display=swap" rel="stylesheet">

    <link rel="canonical" href="https://supernest.co.in/" />

</head>

<body class="lng en">
    <div class="loader"></div>
    <div class="header">
        <div class="wrapper">
            <div>
                <a itemprop="url" title="Supernest Plaza By Shreeji Group" href="index.php" class="logo">
                    <img itemprop="logo" class="before" src="img/logo.png" alt="Passcode Big Life by Shree Supernest" title="Passcode Big Life by Shree Supernest" />
                    <img itemprop="logo" class="after" src="img/logo.png" alt="Passcode Big Life by Shree Supernest" title="Passcode Big Life by Shree Supernest" />
                </a>
                <span itemprop="description" style="display:none;">SUPERNEST is a destination being developed by shreeji group in a way that bring good lifestyle and transformation to the place.</span>
                <a itemprop="url" href="#" title="Passcode Big Life by Shree Supernest"></a>
            </div>
            <div id="nav-icon">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
            <div class="menu-wrap">
                <ul class="menu-list">
                    <li class="dropdown about-menu">
                        <a href="#overview">Overview</a>
                    </li>
                    <li class="dropdown wos left">
                        <a href="#amenities">Amenities</a>
                    </li>

                    <li class="right dropdown project">
                        <a href="#plans">Floor Plans</a>
                    </li>
                    <li><a href="#location">Location</a></li>

                </ul>
            </div>
        </div>
        <div class="header-button">
            <a href="javascript:void(0);" class="enquire-now"><img src="images/envelope.png" alt="Enquiry button"> <span>Enquire Now</span></a>
            <!--            <span class="divider"></span>-->
            <!--            <a href="https://api.whatsapp.com/send?phone=919920136399&text=Hi" class="whats-app" target="_blank"><img src="images/whatsapp-img.png" alt="Whatsapp button"> <span>WHATSAPP</span></a>-->
        </div>
    </div>
    <div class="mainPage" id="mainPage">
        <h3 class="page-subtitle" style="text-align:center;">
            Thank you for expressing interest on our website.<br />
            Our expert will get in touch with you shortly.
            <p style="margin:10px auto;" id="shutter">You will be redirected in <span class="timer"></span> seconds</p>
        </h3>
    </div>
    <style>
        #mainPage {
            min-height: 70vh;
            padding-top: 200px;
            max-width: 90vw;
            margin: 0 auto;
        }

        #mainPage h3 {
            font-weight: 300;
        }

        .timer {
            color: #D7B56D
        }

    </style>
    <div class="footer">

        <div class="footer-wrap">
            <div class="wrapper">
                <p id="disclaimer">Disclaimer : This project is registered under MahaRERA Reg. No. P-51800004400 & P-518000047335 available at https://maharera.mahaonline.gov.in | Images are for representation purpose only. | * Terms & Conditions apply.</p>
            </div>

        </div>

        <div class="body-click"></div>
    </div>
    <script language="javascript" type="text/javascript" src="js/slick.js"></script>
    <script language="javascript" type="text/javascript" src="js/jquery.fancybox.js"></script>
    <script language="javascript" async type="text/javascript" src="js/main.js"></script>
    <script language="JavaScript">
        function redirToLocation() {
            var c = 10;
            $('.timer').html(c);
            setInterval(function() {
                c--;
                if (c >= 0) {
                    $('.timer').html(c);
                }
                if (c == 0) {
                    $("#shutter").fadeTo("slow", 0);
                    window.location = "https://supernest.co.in/";
                }
            }, 1000);
        }

        $(document).ready(function() {
            redirToLocation();
        });

    </script>
</body>

</html>
