<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
    <link rel="apple-touch-icon" sizes="180x180" href="favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicons/favicon-16x16.png">
    <link rel="manifest" href="favicons/site.html">
    <link rel="mask-icon" href="favicons/safari-pinned-tab.svg" color="#5bbad5">
    <link rel="shortcut icon" href="favicons/favicon.ico">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="msapplication-config" content="favicons/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
    <title>Passcode Big Life by Shree Supernest - 2 & 3 BHK Super Apartments | Shreeji Group</title>
    <meta name="description" content="Passcode Big Life by Shree Supernest - 2 & 3 BHK Super Apartments" />

    <!--    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />-->
    <link rel="stylesheet" href="css/styles.css" type="text/css" defer />
    <link rel="stylesheet" href="css/fontawesome/css/font-awesome.min.css" type="text/css" defer />
    <link rel="stylesheet" href="css/animate.css" type="text/css" async />
    <link rel="stylesheet" href="css/slick.css" type="text/css" async />
    <link rel="stylesheet" href="css/fancybox/jquery.fancybox.css" type="text/css" async />

    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@600&amp;family=Montserrat:wght@200;300;400;600;800&amp;display=swap" rel="stylesheet">

    <link rel="canonical" href="https://supernest.co.in/" />

</head>

<body class="lng en">
    <div class="loader"></div>
    <div class="header">
        <div class="wrapper">
            <div>
                <a itemprop="url" title="Passcode Big Life by Shree Supernest" href="#" class="logo">
                    <img itemprop="logo" class="before" src="img/logo.png" alt="Passcode Big Life by Shree Supernest" title="Passcode Big Life by Shree Supernest" />
                    <img itemprop="logo" class="after" src="img/logo.png" alt="Passcode Big Life by Shree Supernest" title="Passcode Big Life by Shree Supernest" />
                </a>
                <span itemprop="description" style="display:none;">SUPERNEST is a destination being developed by shreeji group in a way that bring good lifestyle and transformation to the place.</span>
                <a itemprop="url" href="#" title="Passcode Big Life by Shree Supernest"></a>
            </div>
            <div id="nav-icon">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
            <div class="menu-wrap">
                <ul class="menu-list">
                    <li class="dropdown about-menu">
                        <a href="#overview">Overview</a>
                    </li>
                    <li class="dropdown wos left">
                        <a href="#highlights">Amenities</a>
                    </li>

                    <li class="right dropdown project">
                        <a href="#plans">Floor Plans</a>
                    </li>
                    <li><a href="#location">Location</a></li>

                </ul>
            </div>
        </div>
        <div class="header-button">
            <a href="javascript:void(0);" class="enquire-now"><img src="images/envelope.png" alt="Enquiry button"></a>
            <!--            <span class="divider"></span>-->
            <!--            <a href="https://wa.me/+918291933333?text=Hi" class="whats-app" target="_blank"><img src="images/whatsapp-img.png" alt="Whatsapp button"></a>-->
            <!--            <span class="pri-no divider"></span>-->
            <!--            <a class="pri-no nav-link txt-white" href="tel:02240943979" style="font-size: 20px;">022 4094 3979</a>-->
        </div>
    </div>
    <div class="mainPage" id="mainPage">
        <div class="main-wrap">
            <div class="container">
                <section id="home" class="banner banner123">
                    <ul class="home-slider">
                        <li>
                            <img src="img/banner/desk1.jpg" alt="Passcode Big Life by Shree Supernest" title="Passcode Big Life by Shree Supernest" class="desk-only ==32" />
                            <img src="img/banner/mob1.jpg" alt="Passcode Big Life by Shree Supernest" title="Passcode Big Life by Shree Supernest" class="mob-only ==32" />
                        </li>
                        <li>
                            <img src="img/banner/desk2.jpg" alt="Passcode Big Life by Shree Supernest" title="Passcode Big Life by Shree Supernest" class="desk-only ==32" />
                            <img src="img/banner/mob2.jpg" alt="Passcode Big Life by Shree Supernest" title="Passcode Big Life by Shree Supernest" class="mob-only ==32" />
                        </li>
                    </ul>
                </section>
                <section id="overview" class="overview">
                    <div class="wrapper">
                        <div class="content-box">
                            <h1 style="display:none;">Plaza by Shreeji Group</h1>
                            <div class="cell">
                                <div class="heading">
                                    <h2 class="title grad">OVERVIEW</h2>
                                    <span></span>
                                    <h3>
                                        Presenting a milestone inspired by a milestone
                                    </h3>
                                    <h4>
                                        2 & 3 BHK Super Apartments
                                    </h4>
                                    <h6>
                                        Starting From
                                    </h6>
                                    <h5>
                                        <a href="javascript:void(0);" style="font-size: 15px; line-height: 24px;" class="enquire-now">Click to know price</a>
                                    </h5>
                                </div>
                            </div>
                            <div class="cell">
                                <div id="short-overview">
                                    <!--                                    <p class="grad-box">38 Storey Tower</p>-->
                                    <p>
                                        SUPERNEST is a destination being developed by Shreeji Group in a way that
                                        brings a good lifestyle and transformation to the place. It's a series of
                                        developments designed to transform the neighbourhood. Supernest is
                                        spread across 10 acres nestled in the most convenient location of
                                        Orlem-Malad with lifestyle amenities just minutes away.
                                    </p>
                                </div>
                                <div id="expand" style="display:none;">
                                    <p>
                                        SUPERNEST is a destination being developed by Shreeji Group in a way that
                                        brings a good lifestyle and transformation to the place. It's a series of
                                        developments designed to transform the neighbourhood. Supernest is
                                        spread across 10 acres nestled in the most convenient location of
                                        Orlem-Malad with lifestyle amenities just minutes away. Projects like Atlantis Tower A, Aspire, Codename Superlife and
                                        Passcode Big Life are designed for convenience and a good lifestyle
                                        wherein more than 480 families have already shown their trust & booked their dream abode.

                                        LIVE with views of natural & infrastructural wonders.

                                        Supernest becomes the perfect haven to enjoy life to the fullest. Be it large open spaces to enjoy fresh air, relaxing by the pool or letting the little once have fun at the play area, one is always spolit for choice.
                                    </p>
                                </div>
                                <a href="javascript:void(0);" id="ovrview-expnd" class="readmore">Read More</a>
                            </div>
                        </div>
                    </div>
                </section>


                <section id="highlights" class="highlights">
                    <div class="wrapper">
                        <div class="content-box alt">

                            <div class="block">
                                <ul id="highlights-slider">
                                    <li><img src="img/highlight/h2.jpg" /></li>
                                    <li><img src="img/highlight/h1.jpg" /></li>
                                    <li><img src="img/highlight/h3.jpg" /></li>
                                </ul>
                            </div>

                            <div class="block">
                                <div class="heading">
                                    <h2 class="title grad">
                                        Project Highlights
                                    </h2>
                                    <p>9 Reasons to embrace a big life Forever.</p>

                                    <div class="amenity_icons_wrapper">
                                        <!--                                                                                <img src="img/highlight.jpg" />-->

                                        <ul class="location-list">
                                            <li>
                                                <div class="item">
                                                    <div class="imgbox">
                                                        <img src="img/high-icon/Vastu Compliant Homes.png">
                                                    </div>
                                                    <div class="data">
                                                        <p>Vastu Compliant Homes</p>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="item">
                                                    <div class="imgbox">
                                                        <img src="img/high-icon/Spaces-with-Cross-Ventilation.png">
                                                    </div>
                                                    <div class="data">
                                                        <p>Spaces with Cross Ventilation</p>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="item">
                                                    <div class="imgbox">
                                                        <img src="img/high-icon/Clear-Panoramic-Views.png">
                                                    </div>
                                                    <div class="data">
                                                        <p>Clear Panoramic Views</p>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="item">
                                                    <div class="imgbox">
                                                        <img src="img/high-icon/Extra-Utility-Space.png">
                                                    </div>
                                                    <div class="data">
                                                        <p>Extra Utility Space</p>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="item">
                                                    <div class="imgbox">
                                                        <img src="img/high-icon/6-level-Podium-on-each-level.png">
                                                    </div>
                                                    <div class="data">
                                                        <p>6-level Podium on each level</p>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="item">
                                                    <div class="imgbox">
                                                        <img src="img/high-icon/Double-Height-Entrance-Lobby.png">
                                                    </div>
                                                    <div class="data">
                                                        <p>Double Height Entrance Lobby</p>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="item">
                                                    <div class="imgbox">
                                                        <img src="img/high-icon/State-of-the-Art-Elevation.png">
                                                    </div>
                                                    <div class="data">
                                                        <p>State-of-the-Art Elevation</p>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="item">
                                                    <div class="imgbox">
                                                        <img src="img/high-icon/Well-planned-Apartments-with-Natural-Light.png">
                                                    </div>
                                                    <div class="data">
                                                        <p>Well-planned Apartments with Natural Light</p>
                                                    </div>
                                                </div>
                                            </li>

                                        </ul>

                                        <!--
                                        <div>
                                            <div class="col-lg-3">
                                                <div class="amenit-box">
                                                    <img src="img/high-icon/Vastu Compliant Homes.png">
                                                    <p>Vastu Compliant Homes</p>
                                                </div>
                                            </div>
                                            <div class="col-lg-3">
                                                <div class="amenit-box">
                                                    <img src="img/high-icon/Spaces-with-Cross-Ventilation.png">
                                                    <p>Spaces with Cross Ventilation</p>
                                                </div>
                                            </div>
                                            <div class="col-lg-3">
                                                <div class="amenit-box">
                                                    <img src="img/high-icon/Clear-Panoramic-Views.png">
                                                    <p>Clear Panoramic Views</p>
                                                </div>
                                            </div>
                                            <div class="col-lg-3">
                                                <div class="amenit-box">
                                                    <img src="img/high-icon/Extra-Utility-Space.png">
                                                    <p>Extra Utility Space</p>
                                                </div>
                                            </div>
                                            <div class="col-lg-3">
                                                <div class="amenit-box">
                                                    <img src="img/high-icon/6-level-Podium-on-each-level.png">
                                                    <p>6-level Podium on each level</p>
                                                </div>
                                            </div>
                                            <div class="col-lg-3">
                                                <div class="amenit-box">
                                                    <img src="img/high-icon/Double-Height-Entrance-Lobby.png">
                                                    <p>Double Height Entrance Lobby</p>
                                                </div>
                                            </div>
                                            <div class="col-lg-3">
                                                <div class="amenit-box">
                                                    <img src="img/high-icon/State-of-the-Art-Elevation.png">
                                                    <p>State-of-the-Art Elevation</p>
                                                </div>
                                            </div>
                                            <div class="col-lg-3">
                                                <div class="amenit-box">
                                                    <img src="img/high-icon/Well-planned-Apartments-with-Natural-Light.png">
                                                    <p>Well-planned Apartments with Natural Light</p>
                                                </div>
                                            </div>
                                            
                                        <div class="col-lg-3">
                                            <div class="amenit-box">
                                                <img src="img/high-icon/Eco-deck-with-over-35,000-sq.-ft.-of-Recreational-Amenities.png">
                                                <p>Eco-deck with over 35,000 sq.ft. of Recreational Amenities</p>
                                            </div>
                                        </div>

                                        </div>
-->
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>

                </section>

                <section id="amenities" class="amenities">
                    <div class="wrapper">
                        <div class="content-box p-0 ">
                            <div class="heading">
                                <h2 class="title grad">Amenities</h2>
                            </div>
                        </div>
                        <div class="container">
                            <ul id="amenities-slider">
                                <li><img src="img/amenities/1.jpg" /></li>
                                <li><img src="img/amenities/2.jpg" /></li>
                                <li><img src="img/amenities/3.jpg" /></li>
                                <li><img src="img/amenities/4.jpg" /></li>
                                <li><img src="img/amenities/5.jpg" /></li>
                                <li><img src="img/amenities/6.jpg" /></li>
                                <li><img src="img/amenities/7.jpg" /></li>
                                <li><img src="img/amenities/8.jpg" /></li>
                            </ul>
                        </div>
                    </div>
                </section>


                <section id="plans" class="plans">
                    <div class="plan-wrap">
                        <div class="heading">
                            <h2 class="title grad">Floor Plans</h2>
                        </div>
                        <ul class="plan-list">
                            <li>
                                <div class="desk-only">
                                    <a href="javascript:void(0);" class="enquire-now">
                                        <div class="img-box"><img src="images/plans/plan.jpg" class="w100"></div>
                                        <div class="overlay">
                                            <div class="v-align">
                                                <img src="images/ico-view.png">
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="mob-only">
                                    <a href="#" class="" title="Plans" target="_blank">
                                        <div class="img-box"><img src="images/plans/plan.jpg" class="w100"></div>
                                        <div class="overlay">
                                            <div class="v-align">
                                                <img src="images/ico-view.png">
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="data" style="display:none;">
                                    <p>Plans</p>
                                </div>
                            </li>
                        </ul>
                        <a href="#" class="readmore register" style="display:none;">ENQUIRE NOW</a>
                    </div>
                    <div class="brochure-wrap">
                        <ul class="video-list">
                            <a href="#" class="readmore register">
                                <li>
                                    <div class="imgbox">
                                        <img src="images/brochure.jpg" />
                                    </div>
                                    <div class="data">
                                        <h3>Download Brochure</h3>
                                    </div>
                                    <div class="overlay"></div>
                                </li>
                            </a>
                        </ul>
                    </div>
                    <!-- <div class="video-popup v360"> -->
                    <!-- <a href="javascript:void(0);" class="vid-close"></a> -->
                    <!-- <iframe width="560" height="349" src="https://www.youtube.com/embed/QGh6-dqOLLo?rel=0&amp;autoplay=0&amp;autohide=1&amp;wmode=transparent" frameborder="0" allowfullscreen></iframe> -->
                    <!-- </div> -->
                </section>
                <section id="location" class="location">
                    <div class="wrapper">
                        <div class="heading">
                            <h2 class="title grad">LOCATION</h2>
                            <span>Site Address: CTS #216, Gautam Budh Marg, Orlem, Malad West, Mumbai, Maharashtra 400064.</span>
                        </div>
                    </div>
                    <div class="map">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15071.86276514787!2d72.8368581!3d19.1967008!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x8b86eacb54831d6a!2sShreeji%20Atlantis!5e0!3m2!1sen!2sin!4v1668487050212!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                    <div class="location-wrap">
                        <div class="wrapper">
                            <ul class="location-list">
                                <li>
                                    <div class="item">
                                        <div class="imgbox">
                                            <img src="svg/highway.svg" />
                                        </div>
                                        <div class="data">
                                            <h4 dir="auto">10 MINUTES</h4>
                                            <p>WESTERN EXPRESS HIGHWAY</p>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="item">
                                        <div class="imgbox">
                                            <img src="svg/business.svg" />
                                        </div>
                                        <div class="data">
                                            <h4 dir="auto">10 MINUTES</h4>
                                            <p>MINDSCAPE BUSINESS PARK</p>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="item">
                                        <div class="imgbox">
                                            <img src="svg/metro.svg" />
                                        </div>
                                        <div class="data">
                                            <h4 dir="auto">10 MINUTES</h4>
                                            <p>DAHANUKAR WADI METRO</p>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="item">
                                        <div class="imgbox">
                                            <img src="svg/railway-station.svg" />
                                        </div>
                                        <div class="data">
                                            <h4 dir="auto">10 MINUTES</h4>
                                            <p>MALAD RAILWAY STATION</p>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="item">
                                        <div class="imgbox">
                                            <img src="svg/shopping.svg" />
                                        </div>
                                        <div class="data">
                                            <h4 dir="auto">05 MINUTES</h4>
                                            <p>D MART</p>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="item">
                                        <div class="imgbox">
                                            <img src="svg/airport.svg" />
                                        </div>
                                        <div class="data">
                                            <h4 dir="auto">30 MINUTES</h4>
                                            <p>INTERNATIONAL AIRPORT</p>
                                        </div>
                                    </div>
                                </li>

                            </ul>
                        </div>
                    </div>
                </section>

                <section id="landmarks" class="landmarks">
                    <div class="wrapper">
                        <div class="content-box alt p-0 ">
                            <div class="heading">
                                <h2 class="title grad">Major Landmarks</h2>
                            </div>
                        </div>
                        <div class="content-box alt">
                            <div class="block">
                                <img src="images/landmarks/church.jpg" />
                            </div>
                            <div class="block">
                                <img src="images/landmarks/infiniti_mall.jpg" />
                            </div>
                            <div class="block">
                                <img src="images/landmarks/sports_club.jpg" />
                            </div>
                        </div>
                    </div>
                </section>


                <section id="legacy" class="legacy">
                    <div class="wrapper">
                        <div class="content-box alt p-0 ">
                            <div class="heading centered text-center">
                                <img src="images/developer.png" alt="Shreeji Group" style="max-width: 200px; margin-bottom: 50px;" />
                            </div>
                        </div>
                        <div class=" alt text-center p-30">
                            <p>The Shreeji Group is a premier real estate development company that focuses on multi-family residential, SRA & redevelopment projects. The company believes in creating a home or an office based on an understanding of the stated and unstated consumer needs and preferences. </p>
                            <p>The group has left its imprint of excellence across the Mumbai Metropolitan Region, in the form of some iconic projects. More than a business venture, the Shreeji Group is a coming together of ethically inclined professionals, with an abiding commitment towards delivering value, to their customers and stakeholders. This convergence of diverse proficiencies, supported by moral values, has resulted in a unique people-centric business philosophy.

                                The core values of the group thus comprise innovation, design excellence, timeliness, fair business practices and commitment towards the environment. The people-centric and ambitious Shreeji Group is synonymous, with value delivery backed by trust, integrity, competency and timeliness.</p>
                        </div>
                    </div>
                </section>

                <section id="plinthstone" class="plinthstone">
                    <div class="wrapper">
                        <div class="content-box alt p-0">
                            <div class="heading centered text-center">
                                <a href="https://www.blox.xyz/" target="_new">
                                    <img style="max-width: 150px; margin-bottom:30px;" src="images/blox.png" />
                                </a>
                            </div>
                        </div>

                        <!-- <br/> -->
                        <!-- <br/> -->
                        <!-- <div class=" alt text-center p-30"> -->
                        <!-- <p>Plinthstone is a multi-specialty realty advisory company that prides in creating unique solution services for realty industry. Our services are uniquely designed to solve your brand and business problems. <a href="https://www.plinthstone.com" target="_new">Know more</a></p> -->

                        <!-- </div> -->
                    </div>
                </section>
            </div>


        </div>
        <div class="modal-wrap">
            <div class="enquire-form modal-inner">
                <section class="register">
                    <div class="reg-box">
                        <div class="txt-bg">
                            <h2 class="title grad">ENQUIRE NOW</h2>
                        </div>
                        <div class="form-wrap bookvisit-footer">
                            <form id="form1" name="frmEnquiry" class="frmEnquiry" method="get" action="https://plinthstonerema.co.in/public/api/submit-leads">
                                <ul class="form-list">
                                    <li class="col-4">
                                        <div class="form-group">
                                            <input required type="text" class="form-control text" name="name" id="name" placeholder="Name">
                                            <input name="uniqueid" value="<?= random_int(100000, 999999)  + 765438 ?>" type="hidden" />
                                        </div>
                                    </li>
                                    <li class="col-4">
                                        <div class="form-group">
                                            <input required type="text" pattern="[0-9]+" class="form-control text" name="phone" id="phone" placeholder="Mobile No.">
                                        </div>
                                    </li>
                                    <li class="col-4">
                                        <div class="form-group">
                                            <input required type="email" class="form-control text" name="email" id="email" placeholder="Email">
                                            <input type="hidden" name="property" value="28" />
                                        </div>
                                    </li>
                                </ul>
                                <button type="submit" class="submit-button button absolute">SUBMIT</button>
                            </form>
                        </div>
                        <a href="javascript:void(0);" class="btn-close">X</a>
                    </div>
                </section>
            </div>
        </div>
    </div>
    <div class="footer">
        <div class="enquire-form">
            <section class="register ftr">
                <div class="reg-box">
                    <div class="txt-bg">
                        <h2 class="title grad">ENQUIRE NOW</h2>
                    </div>
                    <div class="form-wrap bookvisit-footer">
                        <form id="form2" name="frmEnquiry" class="frmEnquiry" method="get" action="https://plinthstonerema.co.in/public/api/submit-leads">
                            <ul class="form-list">
                                <li class="col-4">
                                    <div class="form-group">
                                        <input required type="text" class="form-control text" name="name" id="name" placeholder="Name">
                                        <input name="uniqueid" value="<?= random_int(100000, 999999)  + 765438 ?>" type="hidden" />
                                    </div>
                                </li>
                                <li class="col-4">
                                    <div class="form-group">
                                        <input required type="text" pattern="[0-9]+" class="form-control text" name="phone" id="phone" placeholder="Mobile No.">
                                    </div>
                                </li>
                                <li class="col-4">
                                    <div class="form-group">
                                        <input required type="email" class="form-control text" name="email" id="email" placeholder="Email">
                                        <input type="hidden" name="property" value="28" />
                                    </div>
                                </li>
                            </ul>
                            <button type="submit" class="submit-button button absolute">SUBMIT</button>
                        </form>
                    </div>
                </div>
            </section>
        </div>
        <div class="footer-wrap">
            <div class="wrapper">
                <p id="disclaimer">Disclaimer : This project is registered under MahaRERA Reg. No. P-51800004400 & P-518000047335 available at https://maharera.mahaonline.gov.in | Images are for representation purpose only. | * Terms & Conditions apply.</p>
            </div>
            <!-- <div class="wrapper"> -->
            <!-- <div class="ftr-btm"> -->

            <!-- <p class="rights">a project by Shreeji Group</p> -->
            <!-- <p class="rera">MahaRERA Reg. No. A Wing : P-51800007051, B Wing : P-51800011168 </p> -->
            <!-- </div> -->
            <!-- </div> -->
        </div>
        <!-- <a href="tel:+971800999999" id="waybeo_num" class="mob-only "></a> -->
        <div class="body-click"></div>
        <div class="expand-right">
            <a href="#" class="mob-only rel-icon">
                <span class="callTomob whatsApp"></span>
            </a>
            <a href="tel:+971800999999" id="waybeo_num" class="mob-only rel-icon">
                <span class="callTomob callUs"></span>
            </a>
            <a href="javascript:void(0)" class="mob-only enquire-now rel-icon">
                <span class="callTomob enquireNow"></span>
            </a>
        </div>
    </div>

    <div class="enquire-form alt fixed">
        <section class="register ftr">
            <div class="reg-box">
                <div class="txt-bg">
                    <h2 class="title grad">ENQUIRE NOW</h2>
                </div>
                <div class="form-wrap bookvisit-footer">
                    <form id="form3" name="frmEnquiry" class="frmEnquiry" method="get" action="https://plinthstonerema.co.in/public/api/submit-leads">
                        <ul class="form-list">
                            <li class="col-4">
                                <div class="form-group">
                                    <input required type="text" placeholder="Name" class="form-control text" name="name" id="name">
                                    <input name="uniqueid" value="<?= random_int(100000, 999999)  + 765438 ?>" type="hidden" />
                                </div>
                            </li>
                            <li class="col-4">
                                <div class="form-group">
                                    <input required type="text" placeholder="Mobile" pattern="[0-9]+" class="form-control text" name="phone" id="phone">
                                </div>
                            </li>
                            <li class="col-4">
                                <div class="form-group">
                                    <input required type="email" placeholder="Email" class="form-control text" name="email" id="email">
                                    <input type="hidden" name="property" value="28" />
                                </div>
                            </li>
                            <li class="col-4">
                                <div class="form-group">
                                    <button type="submit" class="submit-button button">SUBMIT</button>
                                </div>
                            </li>
                        </ul>
                    </form>
                </div>
            </div>
        </section>
    </div>

    <a class="enquire-now" href="javascript:void(0);">
        <div class="fixed-btn-mb">
            <h2 class="title grad">ENQUIRE NOW</h2>
        </div>
    </a>

    <script language="javascript" type="text/javascript" src="js/jquery-3.6.1.min.js"></script>
    <!--    <script language="javascript" type="text/javascript" src="js/bootstrap.bundle.min.js"></script>-->
    <!--    <script language="javascript" type="text/javascript" src="js/jquery-1.7.2.min.js"></script>-->
    <script language="javascript" type="text/javascript" src="js/wow.min.js"></script>
    <script language="javascript" type="text/javascript" src="js/slick.js"></script>
    <script language="javascript" type="text/javascript" src="js/jquery.fancybox.js"></script>
    <script language="javascript" async type="text/javascript" src="js/main.js"></script>


</body>


</html>
