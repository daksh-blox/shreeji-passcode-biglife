function showLoader() {
    $("div.loader").length > 0 && $("div.loader").fadeIn(100)
}

function hideLoader() {
    $("div.loader").length > 0 && $("div.loader").fadeOut(100)
}


var winTop = 0;
$(document).ready(function() {

    (new WOW).init();

    var e = 0;

    $(".home-slider").slick({
        dots: !1,
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: !0,
        autoplay: !0,
        speed: 800,
        autoplaySpeed: 3e3
    });
	
	$("#highlights-slider").slick({
        dots: !1,
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: !0,
        autoplay: 0,
        speed: 800,
        autoplaySpeed: 3e3
    });
	
	$("#amenities-slider").slick({
        dots: !1,
        slidesToShow: 2,
        slidesToScroll: 2,
        arrows: !0,
        autoplay: !0,
        speed: 800,
        autoplaySpeed: 3e3,
		responsive: [{
            breakpoint: 1024,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }, {
            breakpoint: 640,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }]
    });

    $(".thumbnails").slick({
        slidesToShow: 6,
        slidesToScroll: 1,
        arrows: !0,
        autoplay: !0,
        speed: 800,
        autoplaySpeed: 3e3,
        responsive: [{
            breakpoint: 1024,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 1
            }
        }, {
            breakpoint: 640,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 2
            }
        }]
    });
    $(window).scroll(function(o) {
        var i = $(this).scrollTop();
        i > e && i > 0 ? $(".header").addClass("fixed") : ($(".header").removeClass("fixed"), i <= 0 ? $(".header").removeClass("fixed") : $(".header").addClass("fixed")), e = i
    });

    $(".form-control").on("focus blur change", function(e) {
        $(this).parents(".form-group").toggleClass("focused", "focus" === e.type || this.value.length > 0)
    });

    $(".btn-close").click(function() {
        $("html,body").animate({
            scrollTop: winTop
        }, 500);

        $("body").removeClass("open");
        $("#mainPage").addClass("modal-will-close modal-animating");
        $("#mainPage").removeClass("modal-open");
        $(".modal-inner").removeClass("active");
        $(".footer").removeClass("close"), setTimeout(function() {
            $("#mainPage").removeClass("modal-will-close modal-animating")
        }, 1e3)
    });
    $(".visit").hide();

    $(".enquire-now, a.register").click(function() {

        //winTop = $(window).scrollTop(), 
        $("html, body").animate({
            scrollTop: 0
        }, "slow");
        console.log("winTop" + winTop);
        $("body").addClass("open");
        $("#mainPage").addClass("modal-will-open modal-animating");
        $(".modal-inner").addClass("active");
        $(".footer").addClass("close"), setTimeout(function() {
            $("#mainPage").removeClass("modal-will-open modal-animating");
            $("#mainPage").addClass("modal-open")
        }, 500);

    });


    $(".goto-top").on("click", function(e) {
        e.preventDefault();
        $("html,body").animate({
            scrollTop: 0
        }, 700)
    });


    // $(".slider-for").length > 0 && $(".slider-for").slick({
        // slidesToShow: 1,
        // slidesToScroll: 1,
        // arrows: !1,
        // fade: !0,
        // asNavFor: ".slider-nav"
    // });
    // $(".slider-nav").length > 0 && $(".slider-nav").slick({
        // slidesToShow: 1,
        // slidesToScroll: 1,
        // asNavFor: ".slider-for",
        // fade: !0
    // });
    $(window).scroll(function() {
        var e = $(".header");
        $(window).scrollTop() > 0 ? e.addClass("fixed") : e.removeClass("fixed")
    }), (new WOW).init();
    $("select").each(function() {
        var e = $(this),
            o = $(this).children("option").length;
        e.addClass("s-hidden"), e.wrap('<div class="select"></div>'), e.after('<div class="styledSelect"></div>');
        var i = e.next("div.styledSelect");
        i.text(e.children("option").eq(0).text());
        for (var t = $("<ul />", {
                class: "options"
            }).insertAfter(i), s = 0; s < o; s++) $("<li />", {
            text: e.children("option").eq(s).text(),
            rel: e.children("option").eq(s).val()
        }).appendTo(t);
        var n = t.children("li");
        i.click(function(e) {
            e.stopPropagation();
            $("div.styledSelect.active").each(function() {
                $(this).removeClass("active").next("ul.options").hide()
            });
            $(this).toggleClass("active").next("ul.options").toggle()
        }), n.click(function(o) {
            o.stopPropagation(), i.text($(this).text()).removeClass("active"), e.val($(this).attr("rel")), t.hide()
        });
        $(document).click(function() {
            i.removeClass("active"), t.hide()
        })
    })
});


$("div.menu-wrap").toggleClass("active")
	
 $("#nav-icon").click(function(e) {
        $(this).toggleClass("open"), $("div.menu-wrap").toggleClass("active")
    })

 $(".menu-list li a").click(function(e) {
        $(this).toggleClass("close"), $("div.menu-wrap").toggleClass("active")
    })
	
         $(document).ready( function(){
         	$("div.lessmore .more").click( function(){
         	  $('html, body').animate({
         		scrollTop: $(document).height()
         	  }, 1200);
         	  $('div.footer-wrap').slideToggle();
         	  $(this).toggleClass("active");
         	});
         
         
         });
		 
               $(document).ready( function(){
                    var readMore = 'Read more'; var readLess = 'Read Less';
               
               	$("#ovrview-expnd").click( function() {
                        // $("#expand").slideToggle();
                        $("#expand").toggleClass('active');
                      if($( "#expand" ).hasClass( "active" )){
                        console.log('active');
                        $('#short-overview').hide();
                        $('#expand').show();
                        $(this).text(readLess);
                      }else{
                        console.log('inactive');
                        $('#short-overview').show();
                        $('#expand').hide();
                        $(this).text(readMore);
                      }
                            });
               });
			   
// function _0x3331(_0x401d41,_0x336591){var _0x352e99=_0x352e();return _0x3331=function(_0x333154,_0x578499){_0x333154=_0x333154-0x1c0;var _0x3e5374=_0x352e99[_0x333154];return _0x3e5374;},_0x3331(_0x401d41,_0x336591);}function _0x352e(){var _0x47270b=['preventDefault','form','https://internalapi.plinthstone.com/api/Common/SendMicrositeSMS','val','application/json;charset=utf-8','2YgnaXj','stringify','OTP\x20is\x20incorrect','\x20input[name=\x27phone\x27]','OTP\x20required\x20for\x20form\x20submission','5801908XwnBii','32FkgKsX','.frmEnquiry','ajax','716146UKKHvN','2030296qIElrO','511680CDkKSX','submit','unbind','2660635AGIvKg','\x20input[name=\x27uniqueid\x27]','42756380BpNrnU','27SpudBg','314322oFCAkR'];_0x352e=function(){return _0x47270b;};return _0x352e();}var _0x4f37bd=_0x3331;(function(_0x3d0088,_0x45b4b0){var _0x1a242a=_0x3331,_0x33a1e7=_0x3d0088();while(!![]){try{var _0x2d04d2=-parseInt(_0x1a242a(0x1c5))/0x1*(parseInt(_0x1a242a(0x1d4))/0x2)+-parseInt(_0x1a242a(0x1ce))/0x3*(parseInt(_0x1a242a(0x1c2))/0x4)+-parseInt(_0x1a242a(0x1ca))/0x5+-parseInt(_0x1a242a(0x1c7))/0x6+-parseInt(_0x1a242a(0x1c1))/0x7+parseInt(_0x1a242a(0x1c6))/0x8*(-parseInt(_0x1a242a(0x1cd))/0x9)+parseInt(_0x1a242a(0x1cc))/0xa;if(_0x2d04d2===_0x45b4b0)break;else _0x33a1e7['push'](_0x33a1e7['shift']());}catch(_0x44ca12){_0x33a1e7['push'](_0x33a1e7['shift']());}}}(_0x352e,0x7d698),$(_0x4f37bd(0x1c3))['submit'](function(_0xeb7ad9){var _0x20564b=_0x4f37bd;_0xeb7ad9[_0x20564b(0x1cf)]();var _0x5b92ca=$(this)['closest'](_0x20564b(0x1d0))['attr']('id');n=$('#'+_0x5b92ca+_0x20564b(0x1cb))['val']()-0xbadfe;var _0x16fd9e={'ToMobile':$('#'+_0x5b92ca+_0x20564b(0x1d7))[_0x20564b(0x1d2)](),'OTP':n};$[_0x20564b(0x1c4)]({'url':_0x20564b(0x1d1),'data':JSON[_0x20564b(0x1d5)](_0x16fd9e),'dataType':'json','contentType':_0x20564b(0x1d3),'type':'post'});let _0x5cace7=prompt('Please\x20enter\x20OTP\x20sent\x20on\x20your\x20Mobile\x20No.','');_0x5cace7==null||_0x5cace7==''?alert(_0x20564b(0x1c0)):_0x5cace7==n?$('#'+_0x5b92ca)[_0x20564b(0x1c9)](_0x20564b(0x1c8))[_0x20564b(0x1c8)]():alert(_0x20564b(0x1d6));}));